"""
Built-in GHST Plugins

Contains the default plugins that ship with GHST Studio.
"""