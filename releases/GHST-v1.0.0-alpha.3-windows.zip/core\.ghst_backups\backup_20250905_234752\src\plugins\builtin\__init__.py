"""
Built-in FANTOM Plugins

Contains the default plugins that ship with FANTOM Studio.
"""